import type { Paginator } from "@smithy/types";
import { ListContributorInsightsCommandInput, ListContributorInsightsCommandOutput } from "../commands/ListContributorInsightsCommand";
import type { DynamoDBPaginationConfiguration } from "./Interfaces";
/**
 * @public
 */
export declare const paginateListContributorInsights: (config: DynamoDBPaginationConfiguration, input: ListContributorInsightsCommandInput, ...rest: any[]) => Paginator<ListContributorInsightsCommandOutput>;
