import type { Paginator } from "@smithy/types";
import { QueryCommandInput, QueryCommandOutput } from "../commands/QueryCommand";
import type { DynamoDBPaginationConfiguration } from "./Interfaces";
/**
 * @public
 */
export declare const paginateQuery: (config: DynamoDBPaginationConfiguration, input: QueryCommandInput, ...rest: any[]) => Paginator<QueryCommandOutput>;
