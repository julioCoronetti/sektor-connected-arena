"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRuntimeConfig = void 0;
const httpAuthSchemes_1 = require("@aws-sdk/core/httpAuthSchemes");
const protocols_1 = require("@aws-sdk/core/protocols");
const dynamodb_codec_1 = require("@aws-sdk/dynamodb-codec");
const client_1 = require("@smithy/core/client");
const protocols_2 = require("@smithy/core/protocols");
const retry_1 = require("@smithy/core/retry");
const serde_1 = require("@smithy/core/serde");
const httpAuthSchemeProvider_1 = require("./auth/httpAuthSchemeProvider");
const endpointResolver_1 = require("./endpoint/endpointResolver");
const schemas_0_1 = require("./schemas/schemas_0");
const getRuntimeConfig = (config) => {
    return {
        apiVersion: "2012-08-10",
        base64Decoder: config?.base64Decoder ?? serde_1.fromBase64,
        base64Encoder: config?.base64Encoder ?? serde_1.toBase64,
        disableHostPrefix: config?.disableHostPrefix ?? false,
        endpointProvider: config?.endpointProvider ?? endpointResolver_1.defaultEndpointResolver,
        extensions: config?.extensions ?? [],
        httpAuthSchemeProvider: config?.httpAuthSchemeProvider ?? httpAuthSchemeProvider_1.defaultDynamoDBHttpAuthSchemeProvider,
        httpAuthSchemes: config?.httpAuthSchemes ?? [
            {
                schemeId: "aws.auth#sigv4",
                identityProvider: (ipc) => ipc.getIdentityProvider("aws.auth#sigv4"),
                signer: new httpAuthSchemes_1.AwsSdkSigV4Signer(),
            },
        ],
        logger: config?.logger ?? new client_1.NoOpLogger(),
        protocol: config?.protocol ?? protocols_1.AwsJson1_0Protocol,
        protocolSettings: config?.protocolSettings ?? {
            defaultNamespace: "com.amazonaws.dynamodb",
            errorTypeRegistries: schemas_0_1.errorTypeRegistries,
            xmlNamespace: "http://dynamodb.amazonaws.com/doc/2012-08-10/",
            version: "2012-08-10",
            serviceTarget: "DynamoDB_20120810",
            jsonCodec: new dynamodb_codec_1.DynamoDBJsonCodec(),
        },
        retryStrategy: config?.retryStrategy ?? (config?.maxAttempts == null && config?.retryMode == null && retry_1.Retry.v2026
            ? new retry_1.StandardRetryStrategy({
                maxAttempts: 4,
                baseDelay: 25,
            })
            : undefined),
        serviceId: config?.serviceId ?? "DynamoDB",
        urlParser: config?.urlParser ?? protocols_2.parseUrl,
        utf8Decoder: config?.utf8Decoder ?? serde_1.fromUtf8,
        utf8Encoder: config?.utf8Encoder ?? serde_1.toUtf8,
    };
};
exports.getRuntimeConfig = getRuntimeConfig;
